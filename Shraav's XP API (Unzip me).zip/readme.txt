====
XP API - Completely renovated and updated for 1.14 (Should work for 1.13)!
====

I've finally gotten around to wrap up loose ends and package this together as a resource! This new version is completely new and adds a ton of new features! Because of this, I've also included an examples datapack with videos of the datapack's functionality.

All you have to do is drop the `xp_api` into your datapacks folder and `/reload` and it'll set itself up!

This datapack is very simple to use: Just set `xp_input` to what you need and call one of three functions: `xp:instant`, `xp:linear`, and `xp:smooth`.
Example to set bar instantly to 100%
```scoreboard players set @s xp.input 100
function xp:instant```

Here is what each function does:
: `xp:instant` - instantly sets the bar to the input percentage
: `xp:linear` - linearly grows or shrinks the bar over a certain amount of time.
:: `scoreboard players set @s xp.timer <time>` to control the amount of time it should take
:: If xp.timer is not set, automatically uses the default value (adjustable)
: `xp:smooth` - smoothly sets the bar to the input percentage
:: This is a smooth animation that gives a little flavor to the bar
:: `scoreboard players set @s xp.smooth <smoothness>` to control the speed of the animation
:: This value is also controlable via a default value. I suggest you keep this between 2 and 10

The api can also do a bit more then just the simple percentage -> bar.
There are multiple functions you can call before the final `xp:<action>` function: `xp:levels`, `xp:levels_and_bar`, `xp:raw`
: `xp:levels` - adjusts the levels instead of the bar
: `xp:levels_and_bar` - adjusts both the levels and the bar (bar is copied to the levels)
: `xp:raw` - converts the scoreboard input into the direct xp points values. this emulates the mc leveling system.

This example demonstrates how to control both the levels and the bar via a timer
```scoreboard players set @s xp.input 100
scoreboard players set @s xp.timer 200
function xp:levels_and_bar
function xp:linear```

As you see, you can mix and match and really control every aspect of your xp bar.

